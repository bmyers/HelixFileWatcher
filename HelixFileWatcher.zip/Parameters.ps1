$SourceDirectory = "D:\Clients\Sitecore\SolutionFolder"
$DeployTargetWebPath = "C:\inetpub\wwwroot\sc90.local"