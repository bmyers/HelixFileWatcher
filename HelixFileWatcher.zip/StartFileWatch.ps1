. "$PSScriptRoot/Parameters.ps1"
. "$PSScriptRoot/DeploymentDefinitions.ps1"
. "$PSScriptRoot/FileWatchSetup.ps1"